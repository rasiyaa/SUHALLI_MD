while true
do
echo "Starting SUHALLI_MD!"
node .
done